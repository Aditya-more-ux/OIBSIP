let currentInput = "";
let previousInput = "";
let operator = null;

const currentDisplay = document.getElementById("current");
const previousDisplay = document.getElementById("previous");

const numberButtons = document.querySelectorAll("[data-number]");
const operatorButtons = document.querySelectorAll("[data-operator]");
const actionButtons = document.querySelectorAll("[data-action]");


// =========================
// Number Buttons
// =========================

numberButtons.forEach(button => {

    button.addEventListener("click", () => {

        const number = button.dataset.number;

        // Prevent multiple decimal points
        if (number === "." && currentInput.includes(".")) {
            return;
        }

        currentInput += number;

        updateDisplay();
    });

});


// =========================
// Operator Buttons
// =========================

operatorButtons.forEach(button => {

    button.addEventListener("click", () => {

        if (currentInput === "") {
            return;
        }

        // Operator chaining
        if (previousInput !== "" && operator !== null) {

            const result = calculate();

            currentInput = result.toString();
        }

        previousInput = currentInput;
        currentInput = "";

        operator = button.dataset.operator;

        updateDisplay();
    });

});


// =========================
// Action Buttons
// =========================

actionButtons.forEach(button => {

    button.addEventListener("click", () => {

        const action = button.dataset.action;

        if (action === "clear") {
            clearCalculator();
        }

        if (action === "backspace") {
            backspace();
        }

        if (action === "equals") {
            calculateResult();
        }

    });

});


// =========================
// Calculate
// =========================

function calculate() {

    const firstNumber = parseFloat(previousInput);
    const secondNumber = parseFloat(currentInput);

    let result;

    switch (operator) {

        case "+":
            result = firstNumber + secondNumber;
            break;

        case "-":
            result = firstNumber - secondNumber;
            break;

        case "×":
            result = firstNumber * secondNumber;
            break;

        case "÷":

            if (secondNumber === 0) {

                currentDisplay.textContent = "Error";

                return null;
            }

            result = firstNumber / secondNumber;
            break;

        default:
            return secondNumber;
    }

    return result;
}


// =========================
// Equals
// =========================

function calculateResult() {

    if (previousInput === "" || currentInput === "" || operator === null) {
        return;
    }

    const result = calculate();

    if (result === null) {
        previousInput = "";
        currentInput = "";
        operator = null;
        previousDisplay.textContent = "";
        return;
    }

    currentInput = result.toString();

    previousInput = "";
    operator = null;

    updateDisplay();
}


// =========================
// Clear
// =========================

function clearCalculator() {

    currentInput = "";
    previousInput = "";
    operator = null;

    updateDisplay();
}


// =========================
// Backspace
// =========================

function backspace() {

    currentInput = currentInput.slice(0, -1);

    updateDisplay();
}


// =========================
// Update Display
// =========================

function updateDisplay() {

    currentDisplay.textContent =
        currentInput || "0";

    if (previousInput && operator) {

        previousDisplay.textContent =
            previousInput + " " + operator;

    } else {

        previousDisplay.textContent = "";
    }
}