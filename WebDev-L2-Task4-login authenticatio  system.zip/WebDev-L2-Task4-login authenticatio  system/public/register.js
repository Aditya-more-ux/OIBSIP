const registerForm =
    document.getElementById("registerForm");

const message =
    document.getElementById("message");


registerForm.addEventListener(
    "submit",
    async function (event) {

        event.preventDefault();


        const username =
            document.getElementById("username")
                .value
                .trim();


        const email =
            document.getElementById("email")
                .value
                .trim();


        const password =
            document.getElementById("password")
                .value;


        message.textContent = "";
        message.className = "message";


        // Client-side password validation

        if (password.length < 8) {

            message.textContent =
                "Password must be at least 8 characters.";

            message.classList.add("error");

            return;
        }


        if (!/\d/.test(password)) {

            message.textContent =
                "Password must contain at least one number.";

            message.classList.add("error");

            return;
        }


        try {

            const response =
                await fetch(
                    "/api/register",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json"
                        },

                        body: JSON.stringify({
                            username,
                            email,
                            password
                        })
                    }
                );


            const data =
                await response.json();


            if (!response.ok) {

                message.textContent =
                    data.message;

                message.classList.add("error");

                return;
            }


            message.textContent =
                data.message;

            message.classList.add("success");


            registerForm.reset();


            setTimeout(() => {

                window.location.href =
                    "/login";

            }, 1000);

        } catch (error) {

            message.textContent =
                "Unable to connect to server.";

            message.classList.add("error");

        }

    }
);