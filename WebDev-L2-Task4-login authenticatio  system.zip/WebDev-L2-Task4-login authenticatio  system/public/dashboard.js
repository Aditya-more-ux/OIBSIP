const usernameElement =
    document.getElementById("username");

const emailElement =
    document.getElementById("email");

const logoutBtn =
    document.getElementById("logoutBtn");


// ========================================
// Load Logged-in User
// ========================================

async function loadUser() {

    try {

        const response =
            await fetch("/api/me");


        if (!response.ok) {

            window.location.href =
                "/login";

            return;
        }


        const data =
            await response.json();


        usernameElement.textContent =
            data.username;

        emailElement.textContent =
            data.email;

    } catch (error) {

        window.location.href =
            "/login";

    }

}


loadUser();


// ========================================
// Logout
// ========================================

logoutBtn.addEventListener(
    "click",
    async function () {

        try {

            const response =
                await fetch(
                    "/api/logout",
                    {
                        method: "POST"
                    }
                );


            const data =
                await response.json();


            if (data.success) {

                window.location.href =
                    "/login";

            }

        } catch (error) {

            console.error(
                "Logout error:",
                error
            );

        }

    }
);