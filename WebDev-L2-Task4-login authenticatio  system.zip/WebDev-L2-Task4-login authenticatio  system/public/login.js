const loginForm =
    document.getElementById("loginForm");

const message =
    document.getElementById("message");


loginForm.addEventListener(
    "submit",
    async function (event) {

        event.preventDefault();


        const identifier =
            document.getElementById("identifier")
                .value
                .trim();


        const password =
            document.getElementById("password")
                .value;


        message.textContent = "";
        message.className = "message";


        if (!identifier || !password) {

            message.textContent =
                "Please fill in all fields.";

            message.classList.add("error");

            return;
        }


        try {

            const response =
                await fetch(
                    "/api/login",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json"
                        },

                        body: JSON.stringify({
                            identifier,
                            password
                        })
                    }
                );


            const data =
                await response.json();


            if (!response.ok) {

                message.textContent =
                    data.message;

                message.classList.add("error");

                return;
            }


            window.location.href =
                "/dashboard";

        } catch (error) {

            message.textContent =
                "Unable to connect to server.";

            message.classList.add("error");

        }

    }
);