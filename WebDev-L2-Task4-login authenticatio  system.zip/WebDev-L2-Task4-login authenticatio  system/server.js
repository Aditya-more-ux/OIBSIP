const express = require("express");
const session = require("express-session");
const bcrypt = require("bcrypt");
const fs = require("fs/promises");
const path = require("path");
const crypto = require("crypto");

const app = express();

const PORT = 3000;

const VIEWS_DIR = path.join(__dirname, "views");
const PUBLIC_DIR = path.join(__dirname, "public");
const DATA_DIR = path.join(__dirname, "data");
const USERS_FILE = path.join(DATA_DIR, "users.json");


// ========================================
// Middleware
// ========================================

app.use(express.json());

app.use(express.urlencoded({ extended: true }));

app.use(express.static(PUBLIC_DIR));


// ========================================
// Session
// ========================================

app.use(
    session({
        secret:
            process.env.SESSION_SECRET ||
            "change-this-secret-in-a-real-project",

        resave: false,

        saveUninitialized: false,

        cookie: {
            httpOnly: true,
            sameSite: "lax",
            secure: false,
            maxAge: 1000 * 60 * 60
        }
    })
);


// ========================================
// Helper: Make sure data file exists
// ========================================

async function initializeDatabase() {

    await fs.mkdir(DATA_DIR, {
        recursive: true
    });

    try {

        await fs.access(USERS_FILE);

    } catch {

        await fs.writeFile(
            USERS_FILE,
            "[]",
            "utf8"
        );
    }
}


// ========================================
// Read Users
// ========================================

async function getUsers() {

    const data = await fs.readFile(
        USERS_FILE,
        "utf8"
    );

    return JSON.parse(data);
}


// ========================================
// Save Users
// ========================================

async function saveUsers(users) {

    await fs.writeFile(
        USERS_FILE,
        JSON.stringify(users, null, 2),
        "utf8"
    );
}


// ========================================
// Authentication Middleware
// ========================================

function requireAuth(req, res, next) {

    if (!req.session.userId) {

        return res.redirect("/login");
    }

    next();
}


// ========================================
// Pages
// ========================================

app.get("/", (req, res) => {

    res.redirect("/login");

});


app.get("/login", (req, res) => {

    res.sendFile(
        path.join(VIEWS_DIR, "login.html")
    );

});


app.get("/register", (req, res) => {

    res.sendFile(
        path.join(VIEWS_DIR, "register.html")
    );

});


app.get("/dashboard", requireAuth, (req, res) => {

    res.set("Cache-Control", "no-store");

    res.sendFile(
        path.join(VIEWS_DIR, "dashboard.html")
    );

});


// ========================================
// Registration
// ========================================

app.post("/api/register", async (req, res) => {

    try {

        const {
            username,
            email,
            password
        } = req.body;


        // Basic validation

        if (
            !username ||
            !email ||
            !password
        ) {

            return res.status(400).json({
                success: false,
                message: "All fields are required."
            });

        }


        const cleanUsername =
            username.trim();

        const cleanEmail =
            email.trim().toLowerCase();


        // Password validation

        const hasNumber =
            /\d/.test(password);


        if (password.length < 8) {

            return res.status(400).json({
                success: false,
                message:
                    "Password must be at least 8 characters long."
            });

        }


        if (!hasNumber) {

            return res.status(400).json({
                success: false,
                message:
                    "Password must contain at least one number."
            });

        }


        // Email validation

        const emailPattern =
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/;


        if (!emailPattern.test(cleanEmail)) {

            return res.status(400).json({
                success: false,
                message: "Please enter a valid email address."
            });

        }


        // Read existing users

        const users =
            await getUsers();


        // Duplicate check

        const existingUser =
            users.find(user =>
                user.username.toLowerCase() ===
                    cleanUsername.toLowerCase()
                ||
                user.email.toLowerCase() ===
                    cleanEmail
            );


        if (existingUser) {

            return res.status(409).json({
                success: false,
                message:
                    "Username or email is already registered."
            });

        }


        // Hash password

        const passwordHash =
            await bcrypt.hash(
                password,
                12
            );


        // Create user

        const newUser = {

            id: crypto.randomUUID(),

            username: cleanUsername,

            email: cleanEmail,

            passwordHash: passwordHash
        };


        users.push(newUser);


        await saveUsers(users);


        res.status(201).json({

            success: true,

            message:
                "Registration successful. You can now log in."

        });

    } catch (error) {

        console.error(error);

        res.status(500).json({

            success: false,

            message: "Something went wrong."

        });

    }

});


// ========================================
// Login
// ========================================

app.post("/api/login", async (req, res) => {

    try {

        const {
            identifier,
            password
        } = req.body;


        if (!identifier || !password) {

            return res.status(400).json({

                success: false,

                message:
                    "Please enter your username/email and password."

            });

        }


        const users =
            await getUsers();


        const cleanIdentifier =
            identifier.trim().toLowerCase();


        const user =
            users.find(item =>

                item.username.toLowerCase() ===
                    cleanIdentifier

                ||

                item.email.toLowerCase() ===
                    cleanIdentifier

            );


        // Generic error
        // Do not reveal which field is incorrect

        if (!user) {

            return res.status(401).json({

                success: false,

                message:
                    "Invalid username/email or password."

            });

        }


        const passwordMatches =
            await bcrypt.compare(
                password,
                user.passwordHash
            );


        if (!passwordMatches) {

            return res.status(401).json({

                success: false,

                message:
                    "Invalid username/email or password."

            });

        }


        // Create session

        req.session.userId = user.id;


        res.json({

            success: true,

            message: "Login successful."

        });

    } catch (error) {

        console.error(error);

        res.status(500).json({

            success: false,

            message: "Something went wrong."

        });

    }

});


// ========================================
// Current User
// ========================================

app.get("/api/me", requireAuth, async (req, res) => {

    try {

        const users =
            await getUsers();


        const user =
            users.find(
                user =>
                    user.id ===
                    req.session.userId
            );


        if (!user) {

            req.session.destroy(() => {});

            return res.status(401).json({

                success: false,

                message: "Session expired."

            });

        }


        res.json({

            success: true,

            username: user.username,

            email: user.email

        });

    } catch (error) {

        console.error(error);

        res.status(500).json({

            success: false,

            message: "Something went wrong."

        });

    }

});


// ========================================
// Logout
// ========================================

app.post("/api/logout", (req, res) => {

    req.session.destroy(error => {

        if (error) {

            return res.status(500).json({

                success: false,

                message: "Logout failed."

            });

        }


        res.clearCookie("connect.sid");


        res.json({

            success: true,

            message: "Logged out successfully."

        });

    });

});


// ========================================
// Start Server
// ========================================

initializeDatabase()
    .then(() => {

        app.listen(PORT, () => {

            console.log(
                `Server running at http://localhost:${PORT}`
            );

        });

    })
    .catch(error => {

        console.error(
            "Failed to start server:",
            error
        );

    });