function convertTemperature() {

    let input = document.getElementById("temperature").value;
    let unit = document.getElementById("unit").value;

    let error = document.getElementById("error");

    // Clear previous error
    error.textContent = "";

    // Check empty input
    if (input === "") {
        error.textContent = "Please enter a temperature.";
        return;
    }

    let temperature = Number(input);

    // Check valid number
    if (isNaN(temperature)) {
        error.textContent = "Please enter a valid number.";
        return;
    }

    let celsius;
    let fahrenheit;
    let kelvin;

    // Convert from Celsius
    if (unit === "celsius") {

        celsius = temperature;
        fahrenheit = (temperature * 9 / 5) + 32;
        kelvin = temperature + 273.15;

    }

    // Convert from Fahrenheit
    else if (unit === "fahrenheit") {

        fahrenheit = temperature;
        celsius = (temperature - 32) * 5 / 9;
        kelvin = celsius + 273.15;

    }

    // Convert from Kelvin
    else if (unit === "kelvin") {

        kelvin = temperature;
        celsius = temperature - 273.15;
        fahrenheit = (celsius * 9 / 5) + 32;

    }

    // Absolute zero validation
    if (celsius < -273.15) {
        error.textContent =
            "Temperature cannot be below absolute zero (-273.15°C).";
        return;
    }

    // Display results
    document.getElementById("celsius").textContent =
        "Celsius: " + celsius.toFixed(2) + " °C";

    document.getElementById("fahrenheit").textContent =
        "Fahrenheit: " + fahrenheit.toFixed(2) + " °F";

    document.getElementById("kelvin").textContent =
        "Kelvin: " + kelvin.toFixed(2) + " K";
}