// =========================
// Elements
// =========================

const taskInput = document.getElementById("taskInput");
const addTaskBtn = document.getElementById("addTaskBtn");

const pendingList = document.getElementById("pendingList");
const completedList = document.getElementById("completedList");

const pendingCount = document.getElementById("pendingCount");
const completedCount = document.getElementById("completedCount");


// =========================
// Load Tasks
// =========================

let tasks = JSON.parse(localStorage.getItem("tasks")) || [];


// =========================
// Add Task
// =========================

addTaskBtn.addEventListener("click", addTask);

taskInput.addEventListener("keydown", function (event) {

    if (event.key === "Enter") {
        addTask();
    }

});


function addTask() {

    const text = taskInput.value.trim();

    if (text === "") {
        alert("Please enter a task.");
        return;
    }

    const newTask = {

        id: Date.now(),

        text: text,

        completed: false,

        createdAt: new Date().toLocaleString(),

        completedAt: null

    };

    tasks.push(newTask);

    saveTasks();

    renderTasks();

    taskInput.value = "";

    taskInput.focus();
}


// =========================
// Render Tasks
// =========================

function renderTasks() {

    pendingList.innerHTML = "";
    completedList.innerHTML = "";

    const pendingTasks = tasks.filter(task => !task.completed);

    const completedTasks = tasks.filter(task => task.completed);


    // =========================
    // Pending Count
    // =========================

    pendingCount.textContent =
        `${pendingTasks.length} pending`;


    // =========================
    // Completed Count
    // =========================

    completedCount.textContent =
        `${completedTasks.length} completed`;


    // =========================
    // Empty Messages
    // =========================

    if (pendingTasks.length === 0) {

        pendingList.innerHTML =
            `<div class="empty-message">
                🎉 No pending tasks!
            </div>`;

    }


    if (completedTasks.length === 0) {

        completedList.innerHTML =
            `<div class="empty-message">
                No completed tasks yet.
            </div>`;

    }


    // =========================
    // Create Pending Tasks
    // =========================

    pendingTasks.forEach(task => {

        pendingList.appendChild(createTaskElement(task));

    });


    // =========================
    // Create Completed Tasks
    // =========================

    completedTasks.forEach(task => {

        completedList.appendChild(createTaskElement(task));

    });

}


// =========================
// Create Task Element
// =========================

function createTaskElement(task) {

    const taskDiv = document.createElement("div");

    taskDiv.className = task.completed
        ? "task completed"
        : "task";


    // Task Content

    const contentDiv = document.createElement("div");

    contentDiv.className = "task-content";


    const textElement = document.createElement("div");

    textElement.className = "task-text";

    textElement.textContent = task.text;


    const timeElement = document.createElement("small");

    timeElement.className = "task-time";

    if (task.completed) {

        timeElement.textContent =
            `Added: ${task.createdAt} | Completed: ${task.completedAt}`;

    } else {

        timeElement.textContent =
            `Added: ${task.createdAt}`;

    }


    contentDiv.appendChild(textElement);

    contentDiv.appendChild(timeElement);


    // =========================
    // Complete Button
    // =========================

    const completeButton = document.createElement("button");

    completeButton.className = "complete-btn";

    completeButton.textContent =
        task.completed ? "Undo" : "Complete";

    completeButton.dataset.action = "complete";

    completeButton.dataset.id = task.id;


    // =========================
    // Edit Button
    // =========================

    const editButton = document.createElement("button");

    editButton.className = "edit-btn";

    editButton.textContent = "Edit";

    editButton.dataset.action = "edit";

    editButton.dataset.id = task.id;


    // =========================
    // Delete Button
    // =========================

    const deleteButton = document.createElement("button");

    deleteButton.className = "delete-btn";

    deleteButton.textContent = "Delete";

    deleteButton.dataset.action = "delete";

    deleteButton.dataset.id = task.id;


    // Add everything

    taskDiv.appendChild(contentDiv);

    taskDiv.appendChild(completeButton);

    taskDiv.appendChild(editButton);

    taskDiv.appendChild(deleteButton);


    return taskDiv;
}


// =========================
// Button Events
// =========================

document.addEventListener("click", function (event) {

    const button = event.target;

    if (!button.dataset.action) {
        return;
    }

    const id = Number(button.dataset.id);

    const action = button.dataset.action;


    // =========================
    // Complete
    // =========================

    if (action === "complete") {

        toggleComplete(id);

    }


    // =========================
    // Edit
    // =========================

    if (action === "edit") {

        editTask(id);

    }


    // =========================
    // Delete
    // =========================

    if (action === "delete") {

        deleteTask(id);

    }


    // =========================
    // Save Edit
    // =========================

    if (action === "save") {

        saveEditedTask(id);

    }


    // =========================
    // Cancel Edit
    // =========================

    if (action === "cancel") {

        renderTasks();

    }

});


// =========================
// Complete / Undo
// =========================

function toggleComplete(id) {

    const task = tasks.find(task => task.id === id);

    if (!task) {
        return;
    }

    task.completed = !task.completed;


    if (task.completed) {

        task.completedAt = new Date().toLocaleString();

    } else {

        task.completedAt = null;

    }

    saveTasks();

    renderTasks();
}


// =========================
// Delete
// =========================

function deleteTask(id) {

    tasks = tasks.filter(task => task.id !== id);

    saveTasks();

    renderTasks();
}


// =========================
// Edit
// =========================

function editTask(id) {

    const taskDiv = document
        .querySelector(`[data-id="${id}"]`)
        .closest(".task");

    const task = tasks.find(task => task.id === id);

    if (!task) {
        return;
    }


    const contentDiv =
        taskDiv.querySelector(".task-content");


    contentDiv.innerHTML = "";


    const input =
        document.createElement("input");

    input.type = "text";

    input.value = task.text;

    input.className = "edit-input";


    const saveButton =
        document.createElement("button");

    saveButton.textContent = "Save";

    saveButton.className = "save-btn";

    saveButton.dataset.action = "save";

    saveButton.dataset.id = id;


    const cancelButton =
        document.createElement("button");

    cancelButton.textContent = "Cancel";

    cancelButton.className = "cancel-btn";

    cancelButton.dataset.action = "cancel";

    cancelButton.dataset.id = id;


    contentDiv.appendChild(input);

    taskDiv.appendChild(saveButton);

    taskDiv.appendChild(cancelButton);


    // Hide existing buttons

    taskDiv.querySelector(".complete-btn").style.display = "none";
    taskDiv.querySelector(".edit-btn").style.display = "none";
    taskDiv.querySelector(".delete-btn").style.display = "none";


    input.focus();

}


// =========================
// Save Edited Task
// =========================

function saveEditedTask(id) {

    const taskDiv = document
        .querySelector(`[data-id="${id}"]`)
        .closest(".task");

    const input =
        taskDiv.querySelector(".edit-input");

    const newText = input.value.trim();


    if (newText === "") {

        alert("Task cannot be empty.");

        return;
    }


    const task = tasks.find(task => task.id === id);

    if (!task) {
        return;
    }


    task.text = newText;

    saveTasks();

    renderTasks();
}


// =========================
// Local Storage
// =========================

function saveTasks() {

    localStorage.setItem(
        "tasks",
        JSON.stringify(tasks)
    );

}


// =========================
// Initial Render
// =========================

renderTasks();